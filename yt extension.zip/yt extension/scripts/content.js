function initialCleanup() {
  const initialSelectors = [".ytd-banner-promo-renderer-background", '#center', '#logo-icon', '#content-wrapper', '#dismissible'];

  initialSelectors.forEach((selector) => {
    const element = document.querySelector(selector);
    if (element) {
      element.remove();
      console.log(`Initially removed: ${selector}`);
    }
  });
}

document.querySelector("#contents").setAttribute('style', 'position: fixed; bottom: -60px; left: 52px; right: 0; height: 120px; width:95vw;  overflow-y: scroll;');
document.querySelector("#contents").style.overflowY = "scroll";

function continuouslyRemoveElements() {
  const recurringSelectors = ['#content-wrapper', '#dismissible'];

  setInterval(() => {
    recurringSelectors.forEach(selector => {
      const element = document.querySelector(selector);
      if (element) {
        element.remove();
        console.log(`Removed: ${selector}`);
      }
    });
    let a  = location.href;
    if(a != 'https://www.youtube.com/'){
      location.reload()
    }
  }, 500); // Run every 0.5 second
}

// Run both after the page loads
window.addEventListener('load', () => {
  let locationbar = location.origin;
  if (locationbar == "https://www.youtube.com") {
    initialCleanup();
    continuouslyRemoveElements();
    const chips = document.querySelector(".style-scope ytd-page-manager");
    let style = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 30px;
    padding: 20px;
    border-radius: 10px;
    z-index:9999;
    `;
    
    
    chips.style.position = "absolute";
    chips.style.bottom = "45px";
    chips.style.left = "-20px";
    let brand = `
    <div style="scale:3.5;width: 110px; height: 100%; display: block; fill: currentcolor;"><svg xmlns="http://www.w3.org/2000/svg" id="yt-ringo2-svg_yt9" width="93" height="20" viewBox="0 0 93 20" focusable="false" aria-hidden="true" style="pointer-events: none; display: flex;justify-content:space-between;align-items:center; gap:50px;width: 100%; height: 100%;">
  <g>
    <path d="M14.4848 20C14.4848 20 23.5695 20 25.8229 19.4C27.0917 19.06 28.0459 18.08 28.3808 16.87C29 14.65 29 9.98 29 9.98C29 9.98 29 5.34 28.3808 3.14C28.0459 1.9 27.0917 0.94 25.8229 0.61C23.5695 0 14.4848 0 14.4848 0C14.4848 0 5.42037 0 3.17711 0.61C1.9286 0.94 0.954148 1.9 0.59888 3.14C0 5.34 0 9.98 0 9.98C0 9.98 0 14.65 0.59888 16.87C0.954148 18.08 1.9286 19.06 3.17711 19.4C5.42037 20 14.4848 20 14.4848 20Z" fill="#FF0000"></path>
    <path d="M19 10L11.5 5.75V14.25L19 10Z" fill="white"></path>
  </g> 
  <g id="youtube-paths_yt9">
  <path d="M37.1384 18.8999V13.4399L40.6084 2.09994H38.0184L36.6984 7.24994C36.3984 8.42994 36.1284 9.65994 35.9284 10.7999H35.7684C35.6584 9.79994 35.3384 8.48994 35.0184 7.22994L33.7384 2.09994H31.1484L34.5684 13.4399V18.8999H37.1384Z"></path>
  <path d="M44.1003 6.29994C41.0703 6.29994 40.0303 8.04994 40.0303 11.8199V13.6099C40.0303 16.9899 40.6803 19.1099 44.0403 19.1099C47.3503 19.1099 48.0603 17.0899 48.0603 13.6099V11.8199C48.0603 8.44994 47.3803 6.29994 44.1003 6.29994ZM45.3903 14.7199C45.3903 16.3599 45.1003 17.3899 44.0503 17.3899C43.0203 17.3899 42.7303 16.3499 42.7303 14.7199V10.6799C42.7303 9.27994 42.9303 8.02994 44.0503 8.02994C45.2303 8.02994 45.3903 9.34994 45.3903 10.6799V14.7199Z"></path>
  <path d="M52.2713 19.0899C53.7313 19.0899 54.6413 18.4799 55.3913 17.3799H55.5013L55.6113 18.8999H57.6012V6.53994H54.9613V16.4699C54.6812 16.9599 54.0312 17.3199 53.4212 17.3199C52.6512 17.3199 52.4113 16.7099 52.4113 15.6899V6.53994H49.7812V15.8099C49.7812 17.8199 50.3613 19.0899 52.2713 19.0899Z"></path>
  <path d="M62.8261 18.8999V4.14994H65.8661V2.09994H57.1761V4.14994H60.2161V18.8999H62.8261Z"></path>
    <path d="M67.8728 19.0899C69.3328 19.0899 70.2428 18.4799 70.9928 17.3799H71.1028L71.2128 18.8999H73.2028V6.53994H70.5628V16.4699C70.2828 16.9599 69.6328 17.3199 69.0228 17.3199C68.2528 17.3199 68.0128 16.7099 68.0128 15.6899V6.53994H65.3828V15.8099C65.3828 17.8199 65.9628 19.0899 67.8728 19.0899Z"></path>
    <path d="M80.6744 6.26994C79.3944 6.26994 78.4744 6.82994 77.8644 7.73994H77.7344C77.8144 6.53994 77.8744 5.51994 77.8744 4.70994V1.43994H75.3244L75.3144 12.1799L75.3244 18.8999H77.5444L77.7344 17.6999H77.8044C78.3944 18.5099 79.3044 19.0199 80.5144 19.0199C82.5244 19.0199 83.3844 17.2899 83.3844 13.6099V11.6999C83.3844 8.25994 82.9944 6.26994 80.6744 6.26994ZM80.7644 13.6099C80.7644 15.9099 80.4244 17.2799 79.3544 17.2799C78.8544 17.2799 78.1644 17.0399 77.8544 16.5899V9.23994C78.1244 8.53994 78.7244 8.02994 79.3944 8.02994C80.4744 8.02994 80.7644 9.33994 80.7644 11.7299V13.6099Z"></path>
    <path d="M92.6517 11.4999C92.6517 8.51994 92.3517 6.30994 88.9217 6.30994C85.6917 6.30994 84.9717 8.45994 84.9717 11.6199V13.7899C84.9717 16.8699 85.6317 19.1099 88.8417 19.1099C91.3817 19.1099 92.6917 17.8399 92.5417 15.3799L90.2917 15.2599C90.2617 16.7799 89.9117 17.3999 88.9017 17.3999C87.6317 17.3999 87.5717 16.1899 87.5717 14.3899V13.5499H92.6517V11.4999ZM88.8617 7.96994C90.0817 7.96994 90.1717 9.11994 90.1717 11.0699V12.0799H87.5717V11.0699C87.5717 9.13994 87.6517 7.96994 88.8617 7.96994Z"></path>
  </g>
</svg></div><br><br>
`;

let sinput = ` 
<div id="center" class="style-scope ytd-masthead" style="display:flex; justify-content:center; align-items:center;">
<yt-searchbox role="search" client-ve-type="10349" style="display:none" class="ytSearchboxComponentHost ytSearchboxComponentDesktop ytd-masthead ytSearchboxComponentHostDark">
<yt-icon-button id="search-button-narrow" class="style-scope ytd-masthead"><!--css-build:shady--><!--css_build_scope:yt-icon-button--><!--css_build_styles:video.youtube.src.web.polymer.shared.ui.styles.yt_base_styles.yt.base.styles.css.js,video.youtube.src.web.polymer.shared.ui.yt_icon_button.yt.icon.button.css.js--><button id="button" class="style-scope yt-icon-button" aria-label="Search">
<yt-icon class="topbar-icons style-scope ytd-masthead" icon="yt-icons:search" disable-upgrade="">
</yt-icon>
<tp-yt-paper-tooltip for="search-button-narrow" class="style-scope ytd-masthead" disable-upgrade="" hidden="">
Search
</tp-yt-paper-tooltip>
    </button><yt-interaction id="interaction" class="circular style-scope yt-icon-button"><!--css-build:shady--><!--css_build_scope:yt-interaction--><!--css_build_styles:video.youtube.src.web.polymer.shared.ui.styles.yt_base_styles.yt.base.styles.css.js,video.youtube.src.web.polymer.shared.ui.yt_interaction.yt.interaction.css.js--><div class="stroke style-scope yt-interaction"></div><div class="fill style-scope yt-interaction"></div></yt-interaction></yt-icon-button>
    <div id="voice-search-button" class="style-scope ytd-masthead">
    <ytd-button-renderer class="style-scope ytd-masthead" button-renderer="" button-next=""><!--css-build:shady--><yt-button-shape><button class="yt-spec-button-shape-next yt-spec-button-shape-next--text yt-spec-button-shape-next--overlay yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-only-default yt-spec-button-shape-next--enable-backdrop-filter-experiment" title="" aria-label="Search with your voice" aria-disabled="false"><div aria-hidden="true" class="yt-spec-button-shape-next__icon"><span class="ytIconWrapperHost" style="width: 24px; height: 24px;"><span class="yt-icon-shape ytSpecIconShapeHost"><div style="width: 100%; height: 100%; display: block; fill: currentcolor;"><svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" focusable="false" aria-hidden="true" style="pointer-events: none; display: inherit; width: 100%; height: 100%;"><path d="M12 3c-1.66 0-3 1.37-3 3.07v5.86c0 1.7 1.34 3.07 3 3.07s3-1.37 3-3.07V6.07C15 4.37 13.66 3 12 3zm6.5 9h-1c0 3.03-2.47 5.5-5.5 5.5S6.5 15.03 6.5 12h-1c0 3.24 2.39 5.93 5.5 6.41V21h2v-2.59c3.11-.48 5.5-3.17 5.5-6.41z"></path></svg></div></span></span></div><yt-touch-feedback-shape aria-hidden="true" class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--overlay-touch-response"><div class="yt-spec-touch-feedback-shape__stroke"></div><div class="yt-spec-touch-feedback-shape__fill"></div></yt-touch-feedback-shape></button></yt-button-shape><tp-yt-paper-tooltip offset="8" role="tooltip" tabindex="-1" aria-label="tooltip"><!--css-build:shady--><!--css_build_scope:tp-yt-paper-tooltip--><!--css_build_styles:video.youtube.src.web.polymer.shared.ui.styles.yt_base_styles.yt.base.styles.css.js,third_party.javascript.youtube_components.tp_yt_paper_tooltip.tp.yt.paper.tooltip.css.js--><div id="tooltip" class="hidden style-scope tp-yt-paper-tooltip" style-target="tooltip">
    Search with your voice
    </div>
</tp-yt-paper-tooltip></ytd-button-renderer></div>
<div id="ai-companion-button" class="style-scope ytd-masthead" hidden="">
</div>
</div>
`;

let uparrowbutton = `<button id="scrollUpBtn" style="
padding: 10px 15px;
font-size: 20px;
font-weight:bold;
background-color: #333;
color: white;
border: none;
border-radius: 10px;
cursor: pointer;
">
↑
</button>
`

let container = document.createElement("div")
container.innerHTML = ''
container.innerHTML += `<div class="brand-wrapper">${brand}</div>`;
container.innerHTML += `<div class="sinput-wrapper">${sinput}</div>`;
    container.innerHTML += `<div>${uparrowbutton}</div>`;
    container.setAttribute("style", style);
    
    document.querySelector("body").appendChild(container)
    document.querySelector("#content").addEventListener("click", () => {
      })
    document.querySelector("#scrollUpBtn").addEventListener("click", function () {
      const contents = document.querySelector("#contents");
      const isExpanded = contents.style.height === "90vh";
      let brandWrapper = document.querySelector(".brand-wrapper");
      let sinputWrapper = document.querySelector(".sinput-wrapper");

      // Toggle button rotation
      this.style.transform = isExpanded ? "rotate(0deg)" : "rotate(180deg)";
      this.style.transition = "transform 0.3s ease";
      this.style.position = isExpanded ? "fixed" : "absolute";
      container.style.top = isExpanded ? "50%" : "10px";
      sinputWrapper.style.transform = isExpanded ? "" : "translateY(20px)";
      container.style.flexDirection = isExpanded ? "column" : "row";
      chips.style.top = isExpanded ? "" :"5px";
      
      
      // Toggle #contents height
      contents.style.height = isExpanded ? "120px" : "90vh";
      contents.style.transition = "height 0.3s ease";
      brandWrapper.style.display = isExpanded ? "" : "none";
    });
  }
  document.querySelectorAll(".ytContextualSheetLayoutContentContainer").forEach((item)=>{item.style.overflowX = "hidden"})
})